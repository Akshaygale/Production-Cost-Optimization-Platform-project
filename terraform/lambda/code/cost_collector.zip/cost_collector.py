import boto3
import datetime
import json
import os

# Environment variables from Lambda
S3_BUCKET = os.environ.get("S3_BUCKET")

# AWS clients
ce = boto3.client("ce")  # Cost Explorer
s3 = boto3.client("s3")

def lambda_handler(event, context):
    # Define time period
    end = datetime.date.today()
    start = end - datetime.timedelta(days=1)

    # Get cost data
    response = ce.get_cost_and_usage(
        TimePeriod={
            'Start': str(start),
            'End': str(end)
        },
        Granularity='DAILY',
        Metrics=['UnblendedCost']
    )

    # Prepare JSON data
    filename = f"cost-report-{str(end)}.json"
    data = json.dumps(response, indent=4)

    # Save to S3
    s3.put_object(
        Bucket=S3_BUCKET,
        Key=filename,
        Body=data
    )

    print(f"Cost report uploaded to s3://{S3_BUCKET}/{filename}")
    return {"status": "success"}
